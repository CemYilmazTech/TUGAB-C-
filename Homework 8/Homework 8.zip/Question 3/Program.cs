﻿class Program
{
    static void PrintMonth(int a)
    {
        switch (a)
        {
            case 1: Console.WriteLine("January"); break;
            case 2: Console.WriteLine("February"); break;
            case 3: Console.WriteLine("March"); break;
            case 4: Console.WriteLine("April"); break;
            case 5: Console.WriteLine("May"); break;
            case 6: Console.WriteLine("June"); break;
            case 7: Console.WriteLine("July"); break;
            case 8: Console.WriteLine("August"); break;
            case 9: Console.WriteLine("September"); break;
            case 10: Console.WriteLine("October"); break;
            case 11: Console.WriteLine("November"); break;
            case 12: Console.WriteLine("December"); break;
            default: throw new ArgumentOutOfRangeException("Invalid month number. (Must be between 1 and 12 inclusive.)");
        }
    }

    static void Main()
    {
        try
        {
            Console.WriteLine("Enter a month number (1-12):");
            int a = int.Parse(Console.ReadLine());
            PrintMonth(a);
        }
        catch (FormatException caught)
        {
            Console.WriteLine(caught.Message);
        }
        catch (ArgumentOutOfRangeException caught)
        {
            Console.WriteLine(caught.Message);
        }
    }
}